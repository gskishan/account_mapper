# Copyright (c) 2025, Kiranmai and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestProjectDetails(FrappeTestCase):
	pass
